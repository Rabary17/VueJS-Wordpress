<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// extends page template class
class ThemeMXNewsTemplate extends ThemeMXIndexTemplate
{

}