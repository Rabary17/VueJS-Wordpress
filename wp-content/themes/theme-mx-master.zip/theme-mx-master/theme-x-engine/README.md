# theme-x-engine

## Project setup
```
npm install
```

### Watch, Compiles and minifies for production
```
npm run watch
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
